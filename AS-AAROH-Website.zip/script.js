// AS AAROH setup: replace this with your WhatsApp number including country code, without + or spaces.
const WHATSAPP_NUMBER = "91XXXXXXXXXX";
const products = [
  {id:1,name:"The Everyday Vessel",category:"Home",price:499,symbol:"V",tag:"HOME EDIT",desc:"A simple accent for your everyday spaces."},
  {id:2,name:"Soft Touch Essentials",category:"Personal Care",price:299,symbol:"S",tag:"SELF CARE",desc:"A little care, built into your routine."},
  {id:3,name:"Classic Carry Pouch",category:"Accessories",price:349,symbol:"A",tag:"DAILY STYLE",desc:"A versatile companion for everyday plans."},
  {id:4,name:"Calm Living Set",category:"Lifestyle",price:799,symbol:"C",tag:"LIFESTYLE",desc:"Thoughtful details for slower moments."},
  {id:5,name:"Modern Desk Accent",category:"Home",price:599,symbol:"M",tag:"WORKSPACE",desc:"Bring a considered touch to your desk."},
  {id:6,name:"Daily Comfort Kit",category:"Personal Care",price:449,symbol:"D",tag:"EVERYDAY",desc:"Simple essentials for daily comfort."},
  {id:7,name:"The Minimal Wallet",category:"Accessories",price:699,symbol:"W",tag:"ACCESSORIES",desc:"A clean, timeless everyday accessory."},
  {id:8,name:"Weekend Edit",category:"Lifestyle",price:899,symbol:"E",tag:"CURATED PICK",desc:"A curated idea for your time off."}
];
let cart = JSON.parse(localStorage.getItem("aaroh-cart") || "[]");
let activeCategory = "All";
const grid = document.getElementById("productGrid");
const money = n => "₹" + n.toLocaleString("en-IN");

function renderProducts(){
  const q = (document.getElementById("searchInput").value || "").toLowerCase();
  const list = products.filter(p => (activeCategory==="All" || p.category===activeCategory) && (p.name.toLowerCase().includes(q) || p.category.toLowerCase().includes(q)));
  grid.innerHTML = list.length ? list.map(p=>`<article class="product-card">
    <div class="product-image"><span class="product-tag">${p.tag}</span><span class="product-symbol">${p.symbol}</span></div>
    <div class="product-info"><h3>${p.name}</h3><div class="product-meta"><span>${money(p.price)}</span><button class="add-btn" onclick="addToCart(${p.id})">ADD TO BAG +</button></div></div>
  </article>`).join("") : '<p>No products found. Try another search.</p>';
}
function saveCart(){localStorage.setItem("aaroh-cart",JSON.stringify(cart));renderCart()}
function addToCart(id){const item=cart.find(x=>x.id===id);if(item)item.qty++;else cart.push({id,qty:1});saveCart();showToast("Added to your bag")}
function changeQty(id,delta){const item=cart.find(x=>x.id===id);if(!item)return;item.qty+=delta;if(item.qty<=0)cart=cart.filter(x=>x.id!==id);saveCart()}
function renderCart(){
  const count=cart.reduce((s,x)=>s+x.qty,0), total=cart.reduce((s,x)=>s+x.qty*products.find(p=>p.id===x.id).price,0);
  document.getElementById("cartCount").textContent=count;document.getElementById("drawerCount").textContent=`(${count})`;document.getElementById("subtotal").textContent=money(total);
  const el=document.getElementById("cartItems");
  el.innerHTML=cart.length?cart.map(x=>{const p=products.find(y=>y.id===x.id);return `<div class="cart-row"><div><b>${p.name}</b><small>${money(p.price)} each</small><div class="qty"><button onclick="changeQty(${p.id},-1)">−</button><span>${x.qty}</span><button onclick="changeQty(${p.id},1)">+</button></div></div><strong>${money(p.price*x.qty)}</strong></div>`}).join(""):'<p class="empty-cart">Your bag is waiting for something lovely.</p>';
}
function showToast(t){const el=document.getElementById("toast");el.textContent=t;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),1800)}
function openCart(){document.getElementById("cartDrawer").classList.add("open");document.getElementById("overlay").classList.add("show")}
function closeCart(){document.getElementById("cartDrawer").classList.remove("open");document.getElementById("overlay").classList.remove("show")}
document.getElementById("cartOpen").onclick=openCart;document.getElementById("cartClose").onclick=closeCart;document.getElementById("overlay").onclick=closeCart;
document.getElementById("searchInput").addEventListener("input",renderProducts);
document.querySelectorAll(".filter").forEach(b=>b.addEventListener("click",()=>{document.querySelector(".filter.active").classList.remove("active");b.classList.add("active");activeCategory=b.dataset.category;renderProducts()}));
document.getElementById("searchToggle").onclick=()=>{document.getElementById("searchInput").focus();document.getElementById("shop").scrollIntoView({behavior:"smooth"})};
document.getElementById("menuToggle").onclick=()=>document.getElementById("nav").classList.toggle("open");
document.getElementById("checkout").onclick=()=>{
  if(!cart.length){showToast("Your bag is empty");return}
  if(WHATSAPP_NUMBER.includes("X")){showToast("Add your WhatsApp number in script.js first");return}
  const lines=cart.map(x=>{const p=products.find(y=>y.id===x.id);return `${p.name} x ${x.qty} — ${money(p.price*x.qty)}`});
  const total=cart.reduce((s,x)=>s+x.qty*products.find(p=>p.id===x.id).price,0);
  const msg=`Hello AS AAROH, I would like to place an order:\n${lines.join("\n")}\nSubtotal: ${money(total)}\nPlease confirm availability, delivery charges and payment options.`;
  window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`,"_blank");
};
document.getElementById("contactWhatsApp").onclick=(e)=>{if(WHATSAPP_NUMBER.includes("X")){e.preventDefault();showToast("Add your WhatsApp number in script.js first")}else e.currentTarget.href=`https://wa.me/${WHATSAPP_NUMBER}`};
document.getElementById("year").textContent=new Date().getFullYear();
renderProducts();renderCart();